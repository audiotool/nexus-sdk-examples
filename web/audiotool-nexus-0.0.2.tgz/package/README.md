# TODO

- [ ] look into increasing precision of proto's options.
- [x] improve documenation on how to get started
- [x] emphatise that the package only works in web for now
- [ ] improve error message if you're logged out when generating PATs; very confusing
- [ ] error when creating pat to 1 year
- [ ] highlight that no parameters need to be set in `t.create`, fallback to default
- [x] make it more clear what's missing if calling `modify` before calling `start()`
- [x] add entity.is options
- [ ] correct mistake `onRemove("tonematrix", )`
- [ ] add ability to say:
  - [ ] `t.create("*", ...)`
  - [ ] `t.remove("tonematrix", ...)` or `t.remove("*", ...)`
- [ ] allow async callbacks on `events`?
- [ ] second argument to callbacks: transaction builder _if_ change is local, so that:
  - callbacks can modify things if created locally
  - callbacks can distinguish local changes from remote ones, to react only to local ones
  - change name from `modify` - feels like it's running sync, but isn't.
  - remove `fields`, `array` subtypes
  - consolidate names `entity.id`, `location.entityId`
  - guideline for simplifying api: allow to understand how to use the API if audiotool is understood
  - tick conversions, tick constants
  - link to places something can point to
  - tutorial on how to create patterns for nexus objects/entities e.g. rasselbockPattern
  - links to objects like transaction builder & query builder for visibility

CORS: FIX!!

Studio issues:

- connections not seen
- desktop placement removed doesn't remove the device
- lots of bugs, in consolidator

Expose:

- tick constants
- device size
- device category
- when creating device (constructor) also add field constraints
